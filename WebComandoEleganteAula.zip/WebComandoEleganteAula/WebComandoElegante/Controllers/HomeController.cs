﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebComandoElegante.Models;

namespace WebComandoElegante.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            var repositorio = new RepositorioDados();

            try
            {

                // lista Produtos
                var produtos = await repositorio.ListaProduto();

                produtos.ForEach(p => { var nomeProduto = p.Nome; });

                //foreach (var item in produtos)
                //{
                //    var produto = item;
                //}

            }
            catch (Exception)
            {

                throw;
            }

            try
            {
                // Valida propriedade
                var usuario = await repositorio.ObtemUsuario();
                var nomeUsuario = usuario.Nome?.Trim().ToUpper();
                //var nomeUsuario = !string.IsNullOrEmpty(usuario.Nome) ? usuario.Nome.Trim().ToUpper() : string.Empty;
            }
            catch (Exception)
            {

                throw;
            }

            try
            {

                // Valida Tamanho 
                var estado = await repositorio.ObtemEstado();
                int? tamanhoNome = estado.Nome?.Length;

                if (estado != null)
                {
                    var nome = estado.Nome;
                }

                var nomeEstado = estado?.Nome;

                //int tamanhoNomeEstado = !string.IsNullOrEmpty(estado.Nome) ? estado.Nome.Length : 0;

            }
            catch (Exception)
            {

                throw;
            }
            return View();
        }


    }
}
