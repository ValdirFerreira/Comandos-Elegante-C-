﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebComandoElegante.Models
{
    public class RepositorioDados
    {
        public async Task<List<Produto>> ListaProduto()
        {
            var produtos = new List<Produto>();

            for (int i = 1; i < 16; i++)
            {
                produtos.Add(new Produto
                {
                    Id = i,
                    Nome = string.Concat("Nome Produto", i.ToString())
                });
            }

            return await Task.FromResult(produtos);
        }

        public async Task<List<Usuario>> ListaUsuario()
        {
            var usuarios = new List<Usuario>();

            for (int i = 1; i < 16; i++)
            {
                usuarios.Add(new Usuario
                {
                    Id = i,
                    Nome = string.Concat("Nome Usuário", i.ToString())
                });
            }

            return await Task.FromResult(usuarios);
        }

        public async Task<List<Estado>> ListaEstado()
        {
            var estados = new List<Estado>();

            for (int i = 1; i < 16; i++)
            {
                estados.Add(new Estado
                {
                    Id = i,
                    Nome = string.Concat("Nome Estado", i.ToString())
                });
            }

            return await Task.FromResult(estados);
        }



        public async Task<Usuario> ObtemUsuario()
        {
            var usuario = new Usuario
            {
                Id = 1,
                Nome = null
            };

            return await Task.FromResult(usuario);
        }

        public async Task<Produto> ObtemProduto()
        {
            var produto = new Produto
            {
                Id = 1,
                Nome = null
            };

            return await Task.FromResult(produto);
        }

        public async Task<Estado> ObtemEstado()
        {
            var estado = new Estado
            {
                Id = 1,
                Nome = " Estado"
            };

            return await Task.FromResult(estado);
        }
    }
}
